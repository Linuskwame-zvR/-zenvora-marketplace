# ZENVORA Marketplace V6 — Launch Package

ZENVORA V6 is the production-oriented marketplace package for Ghana: customers, sellers/resellers, suppliers/wholesalers, admin, PostgreSQL and Paystack.

## Included
- PostgreSQL-backed users, products, suppliers, reseller listings, orders and margins.
- Customer/seller/supplier/admin roles.
- Supplier wholesale catalogue and reseller pricing.
- Private supplier cost and margin tracking.
- Paystack initialization, verification and signed webhook processing.
- Paystack seller subaccount support.
- Helmet security headers and API/auth rate limiting.
- Production startup checks for database and JWT configuration.
- Render web-service + PostgreSQL configuration with a pre-deploy migration command.

## Important: this package is ready to deploy, but it is not deployed from this chat
You still need to connect the repository to Render and enter your private Paystack credentials in Render environment variables. Never commit the Paystack secret key to GitHub or place it in frontend code.

## Deployment order
1. Create a GitHub repository and upload this folder.
2. In Render, create the service from the repository or use the included `render.yaml` Blueprint.
3. Connect the Render PostgreSQL database.
4. Set `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `PAYSTACK_SECRET_KEY`, and `PAYSTACK_CALLBACK_URL` as private environment variables.
5. Deploy and confirm `/api/health` reports PostgreSQL as healthy.
6. In Paystack Test Mode, set the webhook to `https://YOUR-DOMAIN/api/paystack/webhook`.
7. Test registration, supplier listing, reseller listing, checkout, payment verification and webhook delivery.
8. Complete Paystack business activation/compliance before switching to live payments.
9. Add your custom domain after the service is working.

## Demo accounts
The first empty database is seeded with:
- Admin: `admin@zenvora.com` / `ChangeMe123!`
- Seller: `seller@zenvora.com` / `Seller123!`
- Supplier: `supplier@zenvora.com` / `Supplier123!`

Change the admin password before launch. The demo seller/supplier accounts are for testing only.

## Production notes
- Render's default filesystem is ephemeral. Product uploads should ultimately move to durable object storage/CDN rather than relying on local `/uploads` files.
- Use Paystack Test Mode first. Paystack's live environment requires business activation/compliance.
- Define seller/supplier KYC, delivery, returns, refunds, disputes, prohibited goods, commission and payout rules before public launch.
- A production marketplace should also add email verification, password reset, audit logs, stronger validation, order-expiry/stock-reservation handling and durable media storage before scaling.
