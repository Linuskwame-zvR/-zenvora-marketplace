-- ZENVORA production PostgreSQL starting schema
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('customer','seller','supplier','admin')),
  phone TEXT,
  location TEXT,
  paystack_subaccount_code TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id UUID REFERENCES users(id),
  supplier_id UUID REFERENCES users(id),
  source_product_id UUID,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  sku TEXT,
  supplier_cost NUMERIC(14,2),
  price NUMERIC(14,2) NOT NULL,
  stock INTEGER NOT NULL DEFAULT 0,
  location TEXT,
  image TEXT,
  description TEXT,
  fulfillment_mode TEXT NOT NULL DEFAULT 'seller',
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  customer_id UUID REFERENCES users(id),
  total NUMERIC(14,2) NOT NULL,
  currency TEXT NOT NULL DEFAULT 'GHS',
  status TEXT NOT NULL,
  payment_status TEXT NOT NULL DEFAULT 'unpaid',
  fulfillment_status TEXT,
  payment_reference TEXT,
  delivery JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  paid_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id TEXT REFERENCES orders(id) ON DELETE CASCADE,
  product_id UUID REFERENCES products(id),
  seller_id UUID REFERENCES users(id),
  supplier_id UUID REFERENCES users(id),
  name TEXT NOT NULL,
  supplier_cost NUMERIC(14,2),
  unit_price NUMERIC(14,2) NOT NULL,
  quantity INTEGER NOT NULL,
  margin NUMERIC(14,2)
);

CREATE INDEX IF NOT EXISTS products_category_idx ON products(category);
CREATE INDEX IF NOT EXISTS products_supplier_idx ON products(supplier_id);
CREATE INDEX IF NOT EXISTS products_seller_idx ON products(seller_id);
CREATE INDEX IF NOT EXISTS orders_customer_idx ON orders(customer_id);
CREATE INDEX IF NOT EXISTS orders_payment_idx ON orders(payment_status);

ALTER TABLE users ADD CONSTRAINT users_email_lower_check CHECK (email = lower(email));
CREATE UNIQUE INDEX IF NOT EXISTS users_paystack_subaccount_unique_idx ON users(paystack_subaccount_code) WHERE paystack_subaccount_code IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS orders_payment_reference_unique_idx ON orders(payment_reference) WHERE payment_reference IS NOT NULL;
CREATE INDEX IF NOT EXISTS products_active_created_idx ON products(active, created_at DESC);
CREATE INDEX IF NOT EXISTS order_items_supplier_idx ON order_items(supplier_id);
