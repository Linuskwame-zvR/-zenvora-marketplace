let token=localStorage.getItem("zenvora_token")||"";
let user=JSON.parse(localStorage.getItem("zenvora_user")||"null");
let cart=JSON.parse(localStorage.getItem("zenvora_cart")||"[]");

const $=id=>document.getElementById(id);
const money=n=>`GH₵${Number(n).toLocaleString("en-GH",{minimumFractionDigits:2})}`;
function toast(msg){const t=$("toast");t.textContent=msg;t.style.display="block";setTimeout(()=>t.style.display="none",2600)}
function save(){localStorage.setItem("zenvora_cart",JSON.stringify(cart));$("cartCount").textContent=cart.reduce((s,x)=>s+x.quantity,0)}
function api(url,opts={}){opts.headers={...(opts.headers||{}),...(token?{Authorization:`Bearer ${token}`}:{})};if(opts.body&&typeof opts.body!=="string"){opts.headers["Content-Type"]="application/json";opts.body=JSON.stringify(opts.body)}return fetch(url,opts).then(async r=>{const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||"Something went wrong");return d})}

async function loadProducts(){
  const q=encodeURIComponent($("search").value||""); const c=encodeURIComponent($("category").value||"All");
  const products=await api(`/api/products?q=${q}&category=${c}`);
  $("productsGrid").innerHTML=products.map(p=>`<article class="card"><img src="${p.image||'https://via.placeholder.com/800x600?text=ZENVORA'}"><div class="card-body"><div class="muted">${p.category} · ${p.location||"Ghana"}</div><h3>${p.name}</h3><div class="price">${money(p.price)}</div><div class="muted">${p.stock} available</div><button onclick='addToCart(${JSON.stringify(p)})'>Add to cart</button></div></article>`).join("")||"<p>No products found.</p>";
}
function addToCart(p){const x=cart.find(i=>i.productId===p.id);if(x)x.quantity++;else cart.push({productId:p.id,name:p.name,price:p.price,image:p.image,quantity:1});save();toast("Added to cart")}
function showCart(){
  const total=cart.reduce((s,x)=>s+x.price*x.quantity,0);
  $("modalContent").innerHTML=`<h2>Your cart</h2>${cart.length?cart.map((x,i)=>`<div class="seller-product"><div><b>${x.name}</b><div>${money(x.price)} × ${x.quantity}</div></div><button onclick="removeCart(${i});showCart()">Remove</button></div>`).join(""):`<p>Your cart is empty.</p>`}<hr><h3>Total: ${money(total)}</h3>${cart.length?`<button class="primary" onclick="checkout()">Proceed to checkout</button>`:""}`;
  $("modal").classList.remove("hidden");
}
function removeCart(i){cart.splice(i,1);save()}
function openAuth(){ $("modalContent").innerHTML=`<h2>${user?"Your account":"ZENVORA Account"}</h2>${user?`<p>Signed in as <b>${user.name}</b> (${user.role})</p><button onclick="openDashboard()">Open dashboard</button> <button onclick="logout()">Log out</button>`:`<div class="row"><button class="primary" onclick="authForm('login')">Login</button><button onclick="authForm('register')">Create account</button></div><p class="muted">Sellers can choose “Seller” during registration.</p>`}`;$("modal").classList.remove("hidden")}
function authForm(mode){
  $("modalContent").innerHTML=mode==="login"?`<h2>Login</h2><form class="form" onsubmit="login(event)"><input id="email" type="email" placeholder="Email" required><input id="password" type="password" placeholder="Password" required><button class="primary">Login</button></form>`:`<h2>Create ZENVORA account</h2><form class="form" onsubmit="register(event)"><input id="name" placeholder="Full name / business name" required><input id="email" type="email" placeholder="Email" required><input id="password" type="password" placeholder="Password (6+ characters)" required><select id="role"><option value="customer">I want to buy</option><option value="seller">I want to sell</option><option value="supplier">I am a supplier / wholesaler</option></select><input id="phone" placeholder="Phone / WhatsApp"><input id="location" placeholder="City / location"><button class="primary">Create account</button></form>`;
}
async function login(e){e.preventDefault();try{const d=await api("/api/auth/login",{method:"POST",body:{email:$("email").value,password:$("password").value}});setSession(d);closeModal();toast("Welcome back");openDashboard()}catch(e){toast(e.message)}}
async function register(e){e.preventDefault();try{const d=await api("/api/auth/register",{method:"POST",body:{name:$("name").value,email:$("email").value,password:$("password").value,role:$("role").value,phone:$("phone").value,location:$("location").value}});setSession(d);closeModal();toast("Account created");openDashboard()}catch(e){toast(e.message)}}
function setSession(d){token=d.token;user=d.user;localStorage.setItem("zenvora_token",token);localStorage.setItem("zenvora_user",JSON.stringify(user))}
function logout(){token="";user=null;localStorage.removeItem("zenvora_token");localStorage.removeItem("zenvora_user");closeModal();$("dashboard").classList.add("hidden");toast("Logged out")}
function closeModal(){$("modal").classList.add("hidden")}
function openSeller(){if(!user){openAuth();authForm("register");$("role").value="seller";return}if(user.role!=="seller"&&user.role!=="admin"){toast("Create a seller account to list products");return}openDashboard()}
async function openDashboard(){
  closeModal();$("dashboard").classList.remove("hidden");$("dashboard").scrollIntoView({behavior:"smooth"});
  if(!user){$("dashContent").innerHTML="<p>Please log in.</p>";return}
  if(user.role==="admin"){const s=await api("/api/admin/stats");$("dashContent").innerHTML=`<div class="statgrid">${Object.entries(s).map(([k,v])=>`<div class="stat"><span>${k}</span><strong>${typeof v==="number"&&k==="revenue"?money(v):v}</strong></div>`).join("")}</div><h3>Admin</h3><p>Use the server/API to manage platform settings and seller payouts.</p>`;return}
  if(user.role==="supplier"){
    const ps=await api("/api/supplier/products");
    const os=await api("/api/supplier/orders");
    $("dashContent").innerHTML=`<div class="row"><button class="primary" onclick="supplierProductForm()">+ Add wholesale product</button></div>
      <h3>Supplier catalogue</h3>${ps.map(p=>`<div class="seller-product"><div><b>${p.name}</b><div>Cost: ${money(p.supplierCost)} · stock ${p.stock}</div></div></div>`).join("")||"<p>No wholesale products yet.</p>"}
      <h3>Orders to fulfil</h3>${os.map(o=>`<div class="order"><b>${o.id}</b> · ${o.fulfillmentStatus||"supplier_pending"}<div>${o.items.filter(i=>i.supplierId).map(i=>`${i.name} × ${i.quantity}`).join(", ")}</div><div class="row"><button onclick="supplierStatus('${o.id}','accepted_by_supplier')">Accept</button><button onclick="supplierStatus('${o.id}','packed')">Packed</button><button onclick="supplierStatus('${o.id}','dispatched')">Dispatched</button><button onclick="supplierStatus('${o.id}','delivered')">Delivered</button></div></div>`).join("")||"<p>No supplier orders yet.</p>"}`;
    return;
  }
  if(user.role==="seller"){
    const ps=await api("/api/seller/products");
    $("dashContent").innerHTML=`<div class="row"><button class="primary" onclick="sellerProductForm()">+ Add product</button><button onclick="supplierCatalogue()">Source from suppliers</button><button onclick="sellerPayoutForm()">Connect seller payout</button></div><h3>Your products</h3>${ps.map(p=>`<div class="seller-product"><div><b>${p.name}</b><div>${money(p.price)} · stock ${p.stock}</div></div><button onclick="deleteProduct('${p.id}')">Hide</button></div>`).join("")||"<p>No products yet.</p>"}`;
    return;
  }
  const orders=await api("/api/orders");
  $("dashContent").innerHTML=`<h3>Your orders</h3>${orders.map(o=>`<div class="order"><b>${o.id}</b> · ${o.status}<div>Total: ${money(o.total)} · Payment: ${o.paymentStatus}</div><small>${o.items.map(i=>`${i.name} × ${i.quantity}`).join(", ")}</small></div>`).join("")||"<p>No orders yet.</p>"}`;
}

async function supplierCatalogue(){
  try{
    const ps=await api("/api/supplier/products");
    $("modalContent").innerHTML=`<h2>Supplier catalogue</h2><p class="muted">Choose a wholesale item and set your own ZENVORA selling price.</p>${ps.map(p=>`<div class="order"><b>${p.name}</b><div>Supplier cost: ${money(p.supplierCost)} · Available: ${p.stock}</div><button class="primary" onclick='resellForm(${JSON.stringify(p)})'>List on ZENVORA</button></div>`).join("")||"<p>No supplier products available yet.</p>"}`;
    $("modal").classList.remove("hidden");
  }catch(e){toast(e.message)}
}
function resellForm(p){
 $("modalContent").innerHTML=`<h2>List supplier product</h2><div class="order"><b>${p.name}</b><div>Supplier cost: ${money(p.supplierCost)}</div></div><form class="form" onsubmit="createResellerListing(event,'${p.id}')"><input id="rsp" type="number" step="0.01" value="${Number(p.supplierCost)+Math.max(10,Number(p.supplierCost)*0.1)}" placeholder="Your selling price" required><input id="rss" type="number" value="${p.stock}" placeholder="Stock"><textarea id="rsn" placeholder="Internal margin note"></textarea><button class="primary">Publish listing</button></form>`;
}
async function createResellerListing(e,id){
 e.preventDefault();
 try{await api("/api/reseller/listings",{method:"POST",body:{supplierProductId:id,sellingPrice:$("rsp").value,stock:$("rss").value,commissionOrMarginNote:$("rsn").value}});closeModal();toast("Supplier product listed");openDashboard();loadProducts()}catch(e){toast(e.message)}
}
function supplierProductForm(){
 $("modalContent").innerHTML=`<h2>Add wholesale product</h2><form class="form" onsubmit="createSupplierProduct(event)"><input id="spn" placeholder="Product name" required><select id="spc"><option>Cars & Vehicles</option><option>Spare Parts</option><option>Motor & Motorcycle</option><option>Fashion</option><option>Men's Wear</option><option>Shoes</option><option>Food & Provisions</option><option>Electronics</option><option>Home & Living</option></select><input id="spcost" type="number" step="0.01" placeholder="Wholesale/supplier cost" required><input id="spsuggest" type="number" step="0.01" placeholder="Suggested retail price"><input id="sps" type="number" value="10" placeholder="Stock"><input id="spl" placeholder="Supplier location"><input id="spi" placeholder="Product image URL"><textarea id="spd" placeholder="Description"></textarea><button class="primary">Add to supplier catalogue</button></form>`;
 $("modal").classList.remove("hidden");
}
async function createSupplierProduct(e){
 e.preventDefault();
 try{await api("/api/supplier/products",{method:"POST",body:{name:$("spn").value,category:$("spc").value,supplierCost:$("spcost").value,suggestedPrice:$("spsuggest").value||$("spcost").value,stock:$("sps").value,location:$("spl").value,image:$("spi").value,description:$("spd").value}});closeModal();toast("Wholesale product added");openDashboard();loadProducts()}catch(e){toast(e.message)}
}
async function supplierStatus(id,status){
 try{await api(`/api/supplier/orders/${id}/status`,{method:"PUT",body:{status}});toast("Order status updated");openDashboard()}catch(e){toast(e.message)}
}

function sellerProductForm(){
 $("modalContent").innerHTML=`<h2>Add product</h2><form class="form" onsubmit="createProduct(event)"><input id="pn" placeholder="Product name" required><select id="pc"><option>Cars & Vehicles</option><option>Spare Parts</option><option>Motor & Motorcycle</option><option>Fashion</option><option>Men's Wear</option><option>Shoes</option><option>Food & Provisions</option><option>Electronics</option><option>Home & Living</option></select><input id="pp" type="number" step="0.01" placeholder="Price in GH₵" required><input id="ps" type="number" placeholder="Stock" value="1"><input id="pl" placeholder="Location"><input id="pi" placeholder="Product image URL"><textarea id="pd" placeholder="Description"></textarea><button class="primary">Publish product</button></form>`;$("modal").classList.remove("hidden")
}
async function createProduct(e){e.preventDefault();try{await api("/api/products",{method:"POST",body:{name:$("pn").value,category:$("pc").value,price:$("pp").value,stock:$("ps").value,location:$("pl").value,image:$("pi").value,description:$("pd").value}});closeModal();toast("Product published");openDashboard();loadProducts()}catch(e){toast(e.message)}}
async function deleteProduct(id){if(!confirm("Hide this product?"))return;try{await api(`/api/products/${id}`,{method:"DELETE"});openDashboard();loadProducts()}catch(e){toast(e.message)}}
function sellerPayoutForm(){
 $("modalContent").innerHTML=`<h2>Connect seller payout</h2><p class="muted">Enter the bank details needed to create your Paystack seller subaccount. Verify the details carefully before submitting.</p><form class="form" onsubmit="connectPayout(event)"><input id="bn" placeholder="Business / seller name" required><input id="bc" placeholder="Bank code" required><input id="an" placeholder="Bank account number" required><input id="pcg" type="number" value="10" min="0" max="100" placeholder="Platform commission %"><button class="primary">Connect payout account</button></form>`;$("modal").classList.remove("hidden")
}
async function connectPayout(e){e.preventDefault();try{const d=await api("/api/seller/paystack-subaccount",{method:"POST",body:{business_name:$("bn").value,bank_code:$("bc").value,account_number:$("an").value,percentage_charge:$("pcg").value}});closeModal();toast(d.message);openDashboard()}catch(e){toast(e.message)}}
async function checkout(){
  if(!user){closeModal();openAuth();authForm("login");toast("Login before checkout");return}
  if(user.role!=="customer"){toast("Customer account required for checkout");return}
  try{
    const order=await api("/api/orders",{method:"POST",body:{items:cart.map(x=>({productId:x.productId,quantity:x.quantity})),delivery:{}}});
    const pay=await api("/api/paystack/initialize",{method:"POST",body:{orderId:order.id}});
    window.location.href=pay.authorization_url;
  }catch(e){toast(e.message)}
}
function scrollToProducts(){$("products").scrollIntoView({behavior:"smooth"})}
save();loadProducts();
if(user) $("dashboard").classList.add("hidden");
