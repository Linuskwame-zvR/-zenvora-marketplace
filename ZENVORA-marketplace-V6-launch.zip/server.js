import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import multer from "multer";
import rateLimit from "express-rate-limit";
import helmet from "helmet";
import fs from "fs/promises";
import path from "path";
import crypto from "crypto";
import pg from "pg";

dotenv.config();
const { Pool } = pg;

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ROOT = process.cwd();
const UPLOAD_DIR = path.join(ROOT, "public", "uploads");
const JWT_SECRET = process.env.JWT_SECRET;
const DATABASE_URL = process.env.DATABASE_URL;

if (process.env.NODE_ENV === "production" && (!DATABASE_URL || !JWT_SECRET || JWT_SECRET.length < 32)) {
  throw new Error("Production requires DATABASE_URL and a JWT_SECRET of at least 32 characters.");
}

if (!DATABASE_URL) console.warn("DATABASE_URL is not configured. ZENVORA requires PostgreSQL in V5.");
if (!JWT_SECRET) console.warn("JWT_SECRET is not configured. Set a strong production secret.");

const pool = DATABASE_URL ? new Pool({ connectionString: DATABASE_URL, ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false, max: 10 }) : null;

const defaultProducts = [
  ["Toyota Hilux 2021","Cars & Vehicles",245000,1,"Accra","https://images.unsplash.com/photo-1555215695-3004980ad54e?auto=format&fit=crop&w=900&q=80","Clean Toyota Hilux pickup."],
  ["Full Face Motorcycle Helmet","Motor & Motorcycle",450,20,"Accra","https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=900&q=80","Protective full-face helmet."],
  ["Ladies Long Dress","Fashion",180,30,"Kumasi","https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=900&q=80","Elegant women's fashion dress."],
  ["Premium Sneakers","Shoes",650,18,"Accra","https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80","Premium casual sneakers."],
  ["Food & Provisions Pack","Food & Provisions",350,50,"Tema","https://images.unsplash.com/photo-1601598851547-4302969dcb6b?auto=format&fit=crop&w=900&q=80","Household grocery starter pack."],
  ["iPhone 14 Pro","Electronics",6500,8,"Accra","https://images.unsplash.com/photo-1678652197831-2d180705cd2c?auto=format&fit=crop&w=900&q=80","Apple iPhone 14 Pro."],
  ["Toyota Engine Spare Parts","Spare Parts",1200,12,"Abossey Okai","https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?auto=format&fit=crop&w=900&q=80","Quality vehicle engine spare parts."],
  ["Men's Designer Shirt","Men's Wear",280,25,"Accra","https://images.unsplash.com/photo-1603252110481-7ba873bf42ab?auto=format&fit=crop&w=900&q=80","Smart men's shirt."]
];

async function dbQuery(text, params=[]) {
  if (!pool) throw new Error("DATABASE_URL is not configured");
  return pool.query(text, params);
}
async function withTx(fn) {
  const client = await pool.connect();
  try { await client.query("BEGIN"); const result = await fn(client); await client.query("COMMIT"); return result; }
  catch (e) { await client.query("ROLLBACK"); throw e; }
  finally { client.release(); }
}
async function ensureSchema() {
  if (!pool) return;
  const sql = await fs.readFile(path.join(ROOT,"database-schema.sql"),"utf8");
  await pool.query(sql);
  await seedDemoData();
}
async function seedDemoData() {
  const count = await dbQuery("SELECT COUNT(*)::int AS count FROM users");
  if (count.rows[0].count > 0) return;
  const adminEmail=(process.env.ADMIN_EMAIL||"admin@zenvora.com").toLowerCase();
  const adminHash=await bcrypt.hash(process.env.ADMIN_PASSWORD||"ChangeMe123!",12);
  const sellerHash=await bcrypt.hash("Seller123!",12);
  const supplierHash=await bcrypt.hash("Supplier123!",12);
  const seller=await dbQuery("INSERT INTO users(name,email,password_hash,role,phone,location) VALUES($1,$2,$3,'seller',$4,$5) RETURNING id",["Demo Seller","seller@zenvora.com",sellerHash,"0500000000","Accra"]);
  const supplier=await dbQuery("INSERT INTO users(name,email,password_hash,role,phone,location) VALUES($1,$2,$3,'supplier',$4,$5) RETURNING id",["Accra Wholesale Hub","supplier@zenvora.com",supplierHash,"0550000000","Accra"]);
  await dbQuery("INSERT INTO users(name,email,password_hash,role) VALUES($1,$2,$3,'admin')",["ZENVORA Admin",adminEmail,adminHash]);
  for (const [name,category,price,stock,location,image,description] of defaultProducts) {
    await dbQuery("INSERT INTO products(seller_id,name,category,price,stock,location,image,description,fulfillment_mode) VALUES($1,$2,$3,$4,$5,$6,$7,$8,'seller')",[seller.rows[0].id,name,category,price,stock,location,image,description]);
  }
  const sp=await dbQuery("INSERT INTO products(supplier_id,name,category,supplier_cost,price,stock,location,image,description,fulfillment_mode) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,'supplier') RETURNING id",[supplier.rows[0].id,"Wholesale Motorcycle Helmet","Motor & Motorcycle",330,330,100,"Accra","https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=900&q=80","Wholesale full-face motorcycle helmet."]);
  await dbQuery("UPDATE products SET source_product_id=$1 WHERE id=$1",[sp.rows[0].id]);
}

app.use(helmet({crossOriginResourcePolicy:false}));
app.use(cors({origin:true,credentials:true}));
const apiLimiter = rateLimit({windowMs:15*60*1000,max:300,standardHeaders:true,legacyHeaders:false});
const authLimiter = rateLimit({windowMs:15*60*1000,max:20,standardHeaders:true,legacyHeaders:false,message:{error:"Too many authentication attempts. Please try again later."}});
app.use("/api", apiLimiter);
app.use("/api/auth", authLimiter);
app.use(express.json({limit:"2mb",verify:(req,_res,buf)=>{req.rawBody=buf;}}));
app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(ROOT,"public")));
await fs.mkdir(UPLOAD_DIR,{recursive:true});
const upload=multer({dest:UPLOAD_DIR,limits:{fileSize:5*1024*1024}});

function tokenFor(user){ return jwt.sign({id:user.id,role:user.role,email:user.email},JWT_SECRET||"dev-only-secret",{expiresIn:"7d"}); }
function auth(req,res,next){ const h=req.headers.authorization||""; if(!h.startsWith("Bearer ")) return res.status(401).json({error:"Login required"}); try{req.user=jwt.verify(h.slice(7),JWT_SECRET||"dev-only-secret");next();}catch{return res.status(401).json({error:"Invalid or expired login"});} }
function roles(...allowed){return (req,res,next)=>allowed.includes(req.user.role)?next():res.status(403).json({error:"Not authorized"});}
function gh(amount){return `GH₵${Number(amount).toLocaleString("en-GH",{minimumFractionDigits:2,maximumFractionDigits:2})}`;}
function publicProduct(r){return {...r,id:r.id,sellerId:r.seller_id,supplierId:r.supplier_id,sourceProductId:r.source_product_id,supplierCost:undefined,fulfillmentMode:r.fulfillment_mode,name:r.name,category:r.category,price:Number(r.price),stock:r.stock,location:r.location,image:r.image,description:r.description,active:r.active,createdAt:r.created_at,priceLabel:gh(r.price)};}
function privateProduct(r){return {...publicProduct(r),supplierCost:r.supplier_cost==null?null:Number(r.supplier_cost)};}
async function paystack(pathname,options={}){const key=process.env.PAYSTACK_SECRET_KEY;if(!key)throw new Error("PAYSTACK_SECRET_KEY is not configured");const r=await fetch(`https://api.paystack.co${pathname}`,{...options,headers:{Authorization:`Bearer ${key}`,"Content-Type":"application/json",...(options.headers||{})}});const data=await r.json();if(!r.ok||data.status===false)throw new Error(data.message||"Paystack request failed");return data;}

app.get("/api/health",async(_req,res)=>{try{await dbQuery("SELECT 1");res.json({ok:true,name:"ZENVORA",version:"5.0.0",database:"postgresql"});}catch(e){res.status(503).json({ok:false,name:"ZENVORA",error:"Database unavailable"});}});

app.post("/api/auth/register",async(req,res)=>{try{const {name,email,password,role="customer",phone="",location=""}=req.body;if(!name||!email||!password)return res.status(400).json({error:"Name, email and password are required"});if(password.length<8)return res.status(400).json({error:"Password must be at least 8 characters"});const normalized=email.trim().toLowerCase();const exists=await dbQuery("SELECT id FROM users WHERE email=$1",[normalized]);if(exists.rowCount)return res.status(409).json({error:"Email already registered"});const safeRole=role==="seller"?"seller":"customer";const hash=await bcrypt.hash(password,12);const r=await dbQuery("INSERT INTO users(name,email,password_hash,role,phone,location) VALUES($1,$2,$3,$4,$5,$6) RETURNING id,name,email,role,phone,location",[name.trim(),normalized,hash,safeRole,phone,location]);const u=r.rows[0];res.json({user:u,token:tokenFor(u)});}catch(e){res.status(500).json({error:e.message});}});

app.post("/api/auth/login",async(req,res)=>{try{const email=String(req.body.email||"").trim().toLowerCase();const r=await dbQuery("SELECT * FROM users WHERE email=$1",[email]);const u=r.rows[0];if(!u||!(await bcrypt.compare(req.body.password||"",u.password_hash)))return res.status(401).json({error:"Incorrect email or password"});res.json({user:{id:u.id,name:u.name,email:u.email,role:u.role},token:tokenFor(u)});}catch(e){res.status(500).json({error:e.message});}});
app.get("/api/me",auth,async(req,res)=>{const r=await dbQuery("SELECT id,name,email,role,phone,location,paystack_subaccount_code FROM users WHERE id=$1",[req.user.id]);if(!r.rowCount)return res.status(404).json({error:"User not found"});const u=r.rows[0];res.json({id:u.id,name:u.name,email:u.email,role:u.role,phone:u.phone,location:u.location,paystackSubaccountCode:u.paystack_subaccount_code||""});});

app.get("/api/products",async(req,res)=>{try{let sql="SELECT * FROM products WHERE active=true AND seller_id IS NOT NULL";const p=[];if(req.query.q){p.push(`%${String(req.query.q).toLowerCase()}%`);sql+=` AND LOWER(name||' '||category||' '||COALESCE(location,'')) LIKE $${p.length}`;}if(req.query.category&&req.query.category!=="All"){p.push(req.query.category);sql+=` AND category=$${p.length}`;}sql+=" ORDER BY created_at DESC";const r=await dbQuery(sql,p);res.json(r.rows.map(publicProduct));}catch(e){res.status(500).json({error:e.message});}});

app.post("/api/products",auth,roles("seller","admin"),async(req,res)=>{try{const {name,category,price,stock=1,location="",image="",description=""}=req.body;if(!name||!category||Number(price)<=0)return res.status(400).json({error:"Name, category and a positive price are required"});const sellerId=req.user.role==="admin"?(req.body.sellerId||null):req.user.id;const r=await dbQuery("INSERT INTO products(seller_id,name,category,price,stock,location,image,description,fulfillment_mode) VALUES($1,$2,$3,$4,$5,$6,$7,$8,'seller') RETURNING *",[sellerId,name,category,Number(price),Number(stock),location,image,description]);res.json(privateProduct(r.rows[0]));}catch(e){res.status(500).json({error:e.message});}});

app.put("/api/products/:id",auth,roles("seller","admin"),async(req,res)=>{try{const r=await dbQuery("SELECT * FROM products WHERE id=$1",[req.params.id]);if(!r.rowCount)return res.status(404).json({error:"Product not found"});const p=r.rows[0];if(req.user.role!=="admin"&&String(p.seller_id)!==String(req.user.id))return res.status(403).json({error:"Not your product"});const vals=[req.body.name??p.name,req.body.category??p.category,req.body.price!==undefined?Number(req.body.price):Number(p.price),req.body.stock!==undefined?Number(req.body.stock):p.stock,req.body.location??p.location,req.body.image??p.image,req.body.description??p.description,req.body.active!==undefined?!!req.body.active:p.active,req.params.id];const u=await dbQuery("UPDATE products SET name=$1,category=$2,price=$3,stock=$4,location=$5,image=$6,description=$7,active=$8 WHERE id=$9 RETURNING *",vals);res.json(privateProduct(u.rows[0]));}catch(e){res.status(500).json({error:e.message});}});
app.delete("/api/products/:id",auth,roles("seller","admin"),async(req,res)=>{try{const r=await dbQuery("SELECT * FROM products WHERE id=$1",[req.params.id]);if(!r.rowCount)return res.status(404).json({error:"Product not found"});if(req.user.role!=="admin"&&String(r.rows[0].seller_id)!==String(req.user.id))return res.status(403).json({error:"Not your product"});await dbQuery("UPDATE products SET active=false WHERE id=$1",[req.params.id]);res.json({ok:true});}catch(e){res.status(500).json({error:e.message});}});

app.get("/api/suppliers",auth,roles("admin","seller"),async(_req,res)=>{const r=await dbQuery("SELECT id,name,email,phone,location FROM users WHERE role='supplier' ORDER BY name");res.json(r.rows);});
app.get("/api/supplier/products",auth,roles("supplier","admin"),async(req,res)=>{const r=await dbQuery("SELECT * FROM products WHERE supplier_id=$1 OR ($2='admin' AND supplier_id IS NOT NULL) ORDER BY created_at DESC",[req.user.id,req.user.role]);res.json(r.rows.map(privateProduct));});
app.post("/api/supplier/products",auth,roles("supplier","admin"),async(req,res)=>{try{const {name,category,supplierCost,stock=1,location="",image="",description="",sku=""}=req.body;if(!name||!category||Number(supplierCost)<=0)return res.status(400).json({error:"Name, category and supplier cost are required"});const supplierId=req.user.role==="admin"?(req.body.supplierId||null):req.user.id;if(!supplierId)return res.status(400).json({error:"Supplier is required"});const r=await dbQuery("INSERT INTO products(supplier_id,name,category,supplier_cost,price,stock,location,image,description,sku,fulfillment_mode) VALUES($1,$2,$3,$4,$4,$5,$6,$7,$8,$9,'supplier') RETURNING *",[supplierId,name,category,Number(supplierCost),Number(stock),location,image,description,sku]);res.json(privateProduct(r.rows[0]));}catch(e){res.status(500).json({error:e.message});}});
app.post("/api/reseller/listings",auth,roles("seller","admin"),async(req,res)=>{try{const {supplierProductId,sellingPrice,stock,commissionOrMarginNote=""}=req.body;const src=await dbQuery("SELECT * FROM products WHERE id=$1 AND supplier_id IS NOT NULL",[supplierProductId]);if(!src.rowCount)return res.status(404).json({error:"Supplier product not found"});const s=src.rows[0];if(Number(sellingPrice)<=Number(s.supplier_cost))return res.status(400).json({error:"Selling price must be higher than supplier cost"});const sellerId=req.user.role==="admin"?(req.body.sellerId||null):req.user.id;const r=await dbQuery("INSERT INTO products(seller_id,supplier_id,source_product_id,name,category,supplier_cost,price,stock,location,image,description,sku,fulfillment_mode) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,'supplier') RETURNING *",[sellerId,s.supplier_id,s.id,s.name,s.category,s.supplier_cost,Number(sellingPrice),stock!==undefined?Number(stock):s.stock,s.location,s.image,s.description,s.sku]);res.json(privateProduct(r.rows[0]));}catch(e){res.status(500).json({error:e.message});}});

app.get("/api/supplier/orders",auth,roles("supplier","admin"),async(req,res)=>{const r=await dbQuery(`SELECT o.*,COALESCE(json_agg(json_build_object('productId',oi.product_id,'name',oi.name,'quantity',oi.quantity,'price',oi.unit_price,'supplierCost',oi.supplier_cost,'margin',oi.margin,'sellerId',oi.seller_id,'supplierId',oi.supplier_id)) FILTER (WHERE oi.id IS NOT NULL),'[]') AS items FROM orders o JOIN order_items oi ON oi.order_id=o.id WHERE ($1='admin' OR oi.supplier_id=$2) GROUP BY o.id ORDER BY o.created_at DESC`,[req.user.role,req.user.id]);res.json(r.rows);});
app.put("/api/supplier/orders/:orderId/status",auth,roles("supplier","admin"),async(req,res)=>{const allowed=["supplier_pending","accepted_by_supplier","packed","dispatched","delivered"];if(!allowed.includes(req.body.status))return res.status(400).json({error:"Invalid fulfilment status"});const owns=await dbQuery("SELECT 1 FROM order_items WHERE order_id=$1 AND ($2='admin' OR supplier_id=$3) LIMIT 1",[req.params.orderId,req.user.role,req.user.id]);if(!owns.rowCount)return res.status(403).json({error:"This order is not assigned to your supplier"});let status=req.body.status==="dispatched"?"out_for_delivery":req.body.status==="delivered"?"delivered":undefined;const r=await dbQuery("UPDATE orders SET fulfillment_status=$1,status=COALESCE($2,status) WHERE id=$3 RETURNING *",[req.body.status,status,req.params.orderId]);res.json(r.rows[0]);});

app.get("/api/seller/products",auth,roles("seller","admin"),async(req,res)=>{const r=await dbQuery("SELECT * FROM products WHERE seller_id=$1 OR ($2='admin') ORDER BY created_at DESC",[req.user.id,req.user.role]);res.json(r.rows.map(privateProduct));});

app.get("/api/orders",auth,async(req,res)=>{let r;if(req.user.role==="admin")r=await dbQuery("SELECT * FROM orders ORDER BY created_at DESC");else if(req.user.role==="seller")r=await dbQuery("SELECT DISTINCT o.* FROM orders o JOIN order_items oi ON oi.order_id=o.id WHERE oi.seller_id=$1 ORDER BY o.created_at DESC",[req.user.id]);else r=await dbQuery("SELECT * FROM orders WHERE customer_id=$1 ORDER BY created_at DESC",[req.user.id]);res.json(r.rows);});

app.post("/api/orders",auth,roles("customer","admin"),async(req,res)=>{try{const {items=[],delivery={}}=req.body;if(!Array.isArray(items)||!items.length)return res.status(400).json({error:"Cart is empty"});const order=await withTx(async(client)=>{let total=0;const final=[];for(const item of items){const r=await client.query("SELECT * FROM products WHERE id=$1 AND active=true AND seller_id IS NOT NULL FOR UPDATE",[item.productId]);if(!r.rowCount)throw new Error("A product in the cart is unavailable");const p=r.rows[0];const qty=Math.max(1,Number(item.quantity||1));if(p.stock<qty)throw new Error(`Only ${p.stock} left for ${p.name}`);const margin=p.supplier_cost!=null?(Number(p.price)-Number(p.supplier_cost))*qty:null;final.push({productId:p.id,sellerId:p.seller_id,supplierId:p.supplier_id||null,sourceProductId:p.source_product_id||p.id,supplierCost:p.supplier_cost==null?null:Number(p.supplier_cost),name:p.name,price:Number(p.price),quantity:qty,margin});total+=Number(p.price)*qty;}const id=`ZV-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;const fulfillment=final.some(i=>i.supplierId)?"supplier_pending":"seller_pending";await client.query("INSERT INTO orders(id,customer_id,total,status,payment_status,fulfillment_status,delivery) VALUES($1,$2,$3,'pending_payment','unpaid',$4,$5)",[id,req.user.id,total,fulfillment,delivery]);for(const i of final)await client.query("INSERT INTO order_items(order_id,product_id,seller_id,supplier_id,name,supplier_cost,unit_price,quantity,margin) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)",[id,i.productId,i.sellerId,i.supplierId,i.name,i.supplierCost,i.price,i.quantity,i.margin]);return {id,total,currency:"GHS",status:"pending_payment",paymentStatus:"unpaid",fulfillmentStatus:fulfillment,delivery,items:final};});res.json(order);}catch(e){res.status(400).json({error:e.message});}});

app.post("/api/paystack/initialize",auth,roles("customer","admin"),async(req,res)=>{try{const o=await dbQuery("SELECT * FROM orders WHERE id=$1 AND ($2='admin' OR customer_id=$3)",[req.body.orderId,req.user.role,req.user.id]);if(!o.rowCount)return res.status(404).json({error:"Order not found"});const order=o.rows[0];const c=await dbQuery("SELECT * FROM users WHERE id=$1",[order.customer_id]);const items=await dbQuery("SELECT * FROM order_items WHERE order_id=$1",[order.id]);const sellerIds=[...new Set(items.rows.map(i=>i.seller_id).filter(Boolean))];const sellers=sellerIds.length?await dbQuery("SELECT id,paystack_subaccount_code FROM users WHERE id=ANY($1::uuid[])",[sellerIds]):{rows:[]};const configured=sellers.rows.length===sellerIds.length&&sellers.rows.every(x=>x.paystack_subaccount_code);const commission=Math.min(100,Math.max(0,Number(process.env.PLATFORM_COMMISSION_PERCENT||10)));const payload={email:c.rows[0].email,amount:String(Math.round(Number(order.total)*100)),currency:"GHS",reference:`${order.id}-${crypto.randomBytes(4).toString("hex")}`,callback_url:process.env.PAYSTACK_CALLBACK_URL||`${req.protocol}://${req.get("host")}/payment/callback`,metadata:{orderId:order.id,customerId:order.customer_id}};if(configured){const amounts={};for(const i of items.rows)amounts[i.seller_id]=(amounts[i.seller_id]||0)+Number(i.unit_price)*i.quantity;payload.split={type:"flat",bearer_type:"account",subaccounts:sellers.rows.map(s=>({subaccount:s.paystack_subaccount_code,share:Math.round(amounts[s.id]*100*(1-commission/100))}))};}const data=await paystack("/transaction/initialize",{method:"POST",body:JSON.stringify(payload)});await dbQuery("UPDATE orders SET payment_reference=$1 WHERE id=$2",[data.data.reference,order.id]);res.json({authorization_url:data.data.authorization_url,reference:data.data.reference,splitEnabled:configured});}catch(e){res.status(500).json({error:e.message});}});

async function markPaid(reference){return withTx(async(client)=>{const o=await client.query("SELECT * FROM orders WHERE payment_reference=$1 FOR UPDATE",[reference]);if(!o.rowCount)return null;const order=o.rows[0];if(order.payment_status==="paid")return order;await client.query("UPDATE orders SET payment_status='paid',status='processing',paid_at=NOW() WHERE id=$1",[order.id]);const items=await client.query("SELECT product_id,quantity FROM order_items WHERE order_id=$1",[order.id]);for(const i of items.rows)await client.query("UPDATE products SET stock=GREATEST(0,stock-$1) WHERE id=$2",[i.quantity,i.product_id]);return {...order,payment_status:"paid",status:"processing"};});}
app.get("/api/paystack/verify/:reference",auth,async(req,res)=>{try{const data=await paystack(`/transaction/verify/${encodeURIComponent(req.params.reference)}`);let order=await markPaid(data.data.status==="success"?req.params.reference:"__none__");if(!order){const r=await dbQuery("SELECT * FROM orders WHERE payment_reference=$1",[req.params.reference]);order=r.rows[0]||null;}res.json({status:data.data.status,order});}catch(e){res.status(500).json({error:e.message});}});
app.post("/api/paystack/webhook",async(req,res)=>{try{const signature=req.headers["x-paystack-signature"];const expected=crypto.createHmac("sha512",process.env.PAYSTACK_SECRET_KEY||"").update(req.rawBody||Buffer.from(JSON.stringify(req.body))).digest("hex");if(!signature||signature!==expected)return res.status(401).send("Invalid signature");const event=req.body;if(event.event==="charge.success")await markPaid(event.data.reference);return res.sendStatus(200);}catch(e){return res.status(500).send("Webhook processing failed");}});

app.post("/api/seller/paystack-subaccount",auth,roles("seller","admin"),async(req,res)=>{try{const {business_name,bank_code,account_number,percentage_charge=10}=req.body;if(!business_name||!bank_code||!account_number)return res.status(400).json({error:"Business name, bank code and account number are required"});const data=await paystack("/subaccount",{method:"POST",body:JSON.stringify({business_name,bank_code,account_number,percentage_charge:Number(percentage_charge),primary_contact_email:req.user.email})});const userId=req.user.role==="admin"?(req.body.sellerId||req.user.id):req.user.id;await dbQuery("UPDATE users SET paystack_subaccount_code=$1 WHERE id=$2",[data.data.subaccount_code,userId]);res.json({subaccountCode:data.data.subaccount_code,message:"Seller payout account connected"});}catch(e){res.status(500).json({error:e.message});}});

app.get("/api/admin/margins",auth,roles("admin"),async(_req,res)=>{const r=await dbQuery("SELECT o.id AS order_id,oi.name AS product,oi.quantity,oi.unit_price*oi.quantity AS selling_value,oi.supplier_cost*oi.quantity AS supplier_cost,oi.margin FROM orders o JOIN order_items oi ON oi.order_id=o.id WHERE o.payment_status='paid' AND oi.margin IS NOT NULL ORDER BY o.created_at DESC");res.json({rows:r.rows.map(x=>({...x,sellingValue:Number(x.selling_value),supplierCost:Number(x.supplier_cost),margin:Number(x.margin)})),totalMargin:r.rows.reduce((s,x)=>s+Number(x.margin),0)});});
app.get("/api/admin/stats",auth,roles("admin"),async(_req,res)=>{const r=await dbQuery("SELECT (SELECT COUNT(*) FROM users WHERE role='customer') customers,(SELECT COUNT(*) FROM users WHERE role='seller') sellers,(SELECT COUNT(*) FROM products WHERE active=true AND seller_id IS NOT NULL) products,(SELECT COUNT(*) FROM orders) orders,(SELECT COUNT(*) FROM orders WHERE payment_status='paid') paid_orders,COALESCE((SELECT SUM(total) FROM orders WHERE payment_status='paid'),0) revenue");const x=r.rows[0];res.json({customers:Number(x.customers),sellers:Number(x.sellers),products:Number(x.products),orders:Number(x.orders),paidOrders:Number(x.paid_orders),revenue:Number(x.revenue)});});

app.post("/api/uploads",auth,roles("seller","supplier","admin"),upload.single("image"),(req,res)=>{if(!req.file)return res.status(400).json({error:"Image is required"});res.json({url:`/uploads/${req.file.filename}`});});
app.get("/payment/callback",(_req,res)=>res.send(`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>ZENVORA Payment</title></head><body style="font-family:Arial;padding:40px;text-align:center"><h1>Payment received</h1><p>You can return to ZENVORA and check your order status.</p><a href="/">Return to ZENVORA</a></body></html>`));
app.get("/{*splat}",(_req,res)=>res.sendFile(path.join(ROOT,"public","index.html")));

await ensureSchema();
app.listen(PORT,"0.0.0.0",()=>console.log(`ZENVORA V5 running on port ${PORT}`));
